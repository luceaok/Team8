const express = require("express");
const cors = require("cors");
const mysql = require("mysql");
const bodyParser = require('body-parser');
const http = require('http');
const socketIO = require('socket.io');
const session = require('express-session');

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
    cors: {
        origin: "http://localhost",
        methods: ["GET", "POST"]
    }
});

app.use(cors());
app.use(bodyParser.json());

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "team002"
});

connection.connect((err) => {
    if (err) {
        console.error("Error connecting to MySQL Database:", err);
        return;
    }
    console.log("Connected to MySQL Database!");
});

app.get('/api/user', (req, res) => {
    const userId = req.query.userId;

    const query = `
        SELECT u.*, us.story
        FROM user u
        LEFT JOIN user_story us ON u.id = us.user_id
        WHERE u.id = ?
        ORDER BY us.created_at DESC
        LIMIT 1
    `;

    connection.query(query, [userId], (err, results) => {
        if (err) {
            console.error("Database query error:", err);
            res.status(500).json({ error: "Internal server error" });
        } else {
            if (results.length === 0) {
                res.status(404).json({ error: "User not found" });
            } else {
                res.json(results[0]);
            }
        }
    });
});

app.get('/api/contacts', (req, res) => {
  connection.query("SELECT * FROM user", (err, results) => {
    if (err) {
      console.error("Database query error:", err);
      res.status(500).send("Error fetching contacts data");
    } else {
      res.json(results);
    }
  });
});

app.get('/api/chat-list', (req, res) => {
    const userId = req.query.userId;

    const query = `
        SELECT cr.id, cr.type, 
            CASE 
                WHEN cr.type = 'individual' THEN 
                    CASE 
                        WHEN cr.user1_id = ? THEN (SELECT full_name FROM user WHERE id = cr.user2_id)
                        ELSE (SELECT full_name FROM user WHERE id = cr.user1_id)
                    END
                ELSE cr.name
            END AS name
        FROM chat_room cr
        WHERE cr.type = 'individual' AND (cr.user1_id = ? OR cr.user2_id = ?)
        UNION
        SELECT cr.id, cr.type, cr.name
        FROM chat_room cr
        JOIN group_chat_member gcm ON cr.id = gcm.chat_room_id
        WHERE cr.type = 'group' AND gcm.user_id = ?
    `;

    connection.query(query, [userId, userId, userId, userId], (err, results) => {
        if (err) {
            console.error("Database query error:", err);
            res.status(500).send("Error fetching chat list");
        } else {
            res.json(results);
        }
    });
});

app.get('/api/search', (req, res) => {
    const searchTerm = req.query.term.trim();
    const userId = req.query.userId; // Get the user ID from the request

    if (searchTerm === '') {
        // Return empty results if the search term is empty
        res.json({
            chats: [],
            contacts: []
        });
        return;
    }

    const chatQuery = `
        SELECT cr.id, cr.type, cr.name
        FROM chat_room cr
        WHERE cr.name LIKE ? AND (
            (cr.type = 'individual' AND (cr.user1_id = ? OR cr.user2_id = ?)) OR
            (cr.type = 'group' AND cr.id IN (
                SELECT gcm.chat_room_id
                FROM group_chat_member gcm
                WHERE gcm.user_id = ?
            ))
        )
    `;

    const contactQuery = `
        SELECT u.id, u.full_name AS name
        FROM user u
        WHERE u.full_name LIKE ? AND u.id != ?
    `;

    connection.query(chatQuery, [`%${searchTerm}%`, userId, userId, userId], (err, chatResults) => {
        if (err) {
            console.error("Error searching chat rooms:", err);
            res.status(500).json({ error: "Internal server error" });
            return;
        }

        connection.query(contactQuery, [`%${searchTerm}%`, userId], (err, contactResults) => {
            if (err) {
                console.error("Error searching contacts:", err);
                res.status(500).json({ error: "Internal server error" });
                return;
            }

            res.json({
                chats: chatResults,
                contacts: contactResults
            });
        });
    });
});

app.get('/api/chats/:chatId', (req, res) => {
    const chatId = req.params.chatId;
    const userId = req.query.userId;
    connection.query("SELECT * FROM chat_room WHERE id = ?", [chatId], (err, results) => {
        if (err) {
            console.error("Database query error:", err);
            res.status(500).json({ error: "Internal server error" });
        } else {
            if (results.length === 0) {
                res.status(404).json({ error: "Chat not found" });
            } else {
                const chat = results[0];
                if (chat.type === 'individual') {
                    // Fetch the other user's name and user story for individual chats
                    const otherUserId = chat.user1_id === req.query.userId ? chat.user2_id : chat.user1_id;
                    const query = `
                        SELECT u.full_name, us.story 
                        FROM user u
                        LEFT JOIN user_story us ON u.id = us.user_id
                        WHERE u.id = ?
                        ORDER BY us.created_at DESC
                        LIMIT 1
                    `;
                    connection.query(query, [otherUserId], (err, userResults) => {
                        if (err) {
                            console.error("Database query error:", err);
                            res.status(500).json({ error: "Internal server error" });
                        } else {
                            chat.name = userResults[0].full_name;
                            chat.story = userResults[0].story || ''; // Set empty string if no story found
                            res.json(chat);
                        }
                    });
                } else {
                    res.json(chat);
                }
            }
        }
    });
});

app.get('/api/chats/:chatId/messages', (req, res) => {
    const chatId = req.params.chatId;
    const query = `
        SELECT message.*, user.full_name AS sender_name
        FROM message
        JOIN user ON message.sender_id = user.id
        WHERE message.chat_room_id = ?
    `;
    connection.query(query, [chatId], (err, results) => {
        if (err) {
            console.error("Database query error:", err);
            res.status(500).send("Error fetching messages");
        } else {
            res.json(results);
        }
    });
});

io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('joinChat', (chatId) => {
        socket.join(chatId);
        console.log(`User joined chat room: ${chatId}`);
    });

    socket.on('leaveChat', (chatId) => {
        socket.leave(chatId);
        console.log(`User left chat room: ${chatId}`);
    });

    // Handle the leave group event
    // Handle the leave group event
// Handle the leave group event
socket.on('leaveGroup', (data) => {
    const { chatId, userId } = data;

    // Remove the user from the group chat members table
    const query = 'DELETE FROM group_chat_member WHERE chat_room_id = ? AND user_id = ?';
    connection.query(query, [chatId, userId], (err, result) => {
        if (err) {
            console.error('Error removing user from group chat:', err);
            return;
        }

        console.log(`User ${userId} left group chat ${chatId}`);

        // Notify other members in the group about the user leaving
        socket.to(chatId).emit('memberLeft', {
            chatId: chatId,
            userId: userId
        });

        // Leave the socket room for the group chat
        socket.leave(chatId);
    });
});
// Handle the add member event


socket.on('message', (data) => {
    const { chatId, senderId, content } = data;

    // Check if the chat is an individual chat or a group chat
    connection.query("SELECT type FROM chat_room WHERE id = ?", [chatId], (err, results) => {
        if (err) {
            console.error("Error checking chat type:", err);
            return;
        }

        const chatType = results[0].type;

        if (chatType === 'individual') {
            const query = "INSERT INTO `message` (chat_room_id, sender_id, content, type, created_at) VALUES (?, ?, ?, ?, ?)";
            const values = [chatId, senderId, content, 'text', new Date()];
            connection.query(query, values, (err, result) => {
                if (err) {
                    console.error("Error saving individual message to the database:", err);
                    return;
                }
                
                const senderQuery = "SELECT user.full_name AS sender_name FROM user WHERE user.id = ?";
                connection.query(senderQuery, [senderId], (err, senderResult) => {
                    if (err) {
                        console.error("Error fetching sender name:", err);
                        return;
                    }
                    
                    const senderName = senderResult[0].sender_name;
                    
                    io.to(chatId).emit('message', {
                        id: result.insertId,
                        chat_room_id: chatId,
                        sender_id: senderId,
                        sender_name: senderName,
                        content,
                        type: 'text',
                        created_at: new Date(),
                    });
                });
            });
        } else if (chatType === 'group') {
            const query = "INSERT INTO `message` (chat_room_id, sender_id, content, type, created_at) VALUES (?, ?, ?, ?, ?)";
            const values = [chatId, senderId, content, 'text', new Date()];
            connection.query(query, values, (err, result) => {
                if (err) {
                    console.error("Error saving group message to the database:", err);
                    return;
                }
                
                const senderQuery = "SELECT user.full_name AS sender_name FROM user WHERE user.id = ?";
                connection.query(senderQuery, [senderId], (err, senderResult) => {
                    if (err) {
                        console.error("Error fetching sender name:", err);
                        return;
                    }
                    
                    const senderName = senderResult[0].sender_name;
                    
                    io.to(chatId).emit('message', {
                        id: result.insertId,
                        chat_room_id: chatId,
                        sender_id: senderId,
                        sender_name: senderName,
                        content,
                        type: 'text',
                        created_at: new Date(),
                    });
                });
            });
        }
    });
});

    socket.on('disconnect', () => {
        console.log('A user disconnected');
    });
});

app.post('/api/createChat', (req, res) => {
    const { selectedContacts, chatType, chatName, user1, user2 } = req.body;

    const checkQuery = "SELECT id FROM chat_room WHERE type = 'individual' AND ((user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?))";
    connection.query(checkQuery, [user1, user2, user2, user1], (err, results) => {
        if (err) {
            console.error(err);
            res.status(500).send("Error checking existing chat");
        } else {
            if (results.length > 0) {
                const chatId = results[0].id;
                res.json({ chatId, reload: true }); 
            } else {
                const insertQuery = "INSERT INTO chat_room (name, type, user1_id, user2_id) VALUES (?, ?, ?, ?)";
                connection.query(insertQuery, [chatName, chatType, user1, user2], (err, results) => {
                    if (err) {
                        console.error(err);
                        res.status(500).send("Error adding chat");
                    } else {
                        const chatId = results.insertId;
                        res.json({ chatId, reload: true }); 
                    }
                });
            }
        }
    });
});

app.post('/api/createGroup', (req, res) => {
    const { selectedContacts, chatType, chatName } = req.body;
    
    connection.query("INSERT INTO chat_room (name, type) VALUES (?, ?)", [chatName, chatType], (err, results) => {
        if (err) {
            console.error(err);
            res.status(500).send("Error Adding Group");
        } else {
            console.log("Group has been added");
            
            connection.query("SELECT id from chat_room ORDER BY id desc LIMIT 1", (err, results) => {
                if (err) {
                    console.error(err);
                    res.status(500).send("Error Finding Group");
                } else {
                    const chatId = results[0].id;
                    
                    const insertPromises = selectedContacts.map((userId) => {
                        return new Promise((resolve, reject) => {
                            connection.query("INSERT INTO group_chat_member (chat_room_id, user_id) VALUES (?, ?)", [chatId, userId], (err, results) => {
                                if (err) {
                                    console.error(err);
                                    reject("Error Adding Group Members");
                                } else {
                                    console.log("Member added to group");
                                    resolve();
                                }
                            });
                        });
                    });
                    
                    Promise.all(insertPromises)
                        .then(() => {
                            res.json({ chatId, reload: true }); 
                        })
                        .catch((error) => {
                            console.error(error);
                            res.status(500).send("Error Adding Group Members");
                        });
                }
            });
        }
    });
});

app.get('/api/chats/:chatId/groupInfo', async (req, res) => {
  const chatID = req.params.chatId;
  try {
    const membersResult = await new Promise((resolve, reject) => {
      connection.query("SELECT user_id from group_chat_member WHERE chat_room_id = ?", [chatID], (err, results) => {
        if (err) {
          console.error(err);
          reject("Error with SQL query finding group members");
        } else {
          resolve(results);
        }
      });
    });

    const memberNames = [];
    for (let i = 0; i < membersResult.length; i++) {
      const userId = membersResult[i].user_id;
      const firstNameResult = await new Promise((resolve, reject) => {
        connection.query("SELECT CONCAT(first_name, ' ', last_name) as full_name from user WHERE id = ?", [userId], (err, results) => {
          if (err) {
            console.error(err);
            reject("Error with SQL query finding group members");
          } else {
            resolve(results[0].full_name); // Assuming there's only one result
          }
        });
      });
      memberNames.push(firstNameResult);
    }
    
    res.json(memberNames);
  } catch (error) {
    console.error(error);
    res.status(500).send("Error fetching group info: " + error);
  }
});``

app.get('/api/chats/:chatId/addMember/:memberId', (req, res) => {
  const chatID = req.params.chatId
  const memberID = req.params.memberId
  connection.query("INSERT INTO group_chat_member (chat_room_id, user_id) VALUES(?, ?)", [chatID, memberID], (err, results) => {
   if(err){
    console.error(err)
    res.status(500).send("Error Adding Member to the Group")
   }
   else{
    res.send("Member has been Added!")
   }
  })
})


const PORT = 8080;
server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
