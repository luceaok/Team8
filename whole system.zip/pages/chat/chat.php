<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$userId = $_SESSION["user"] -> id ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chat Application</title>
    <link rel="stylesheet" href="chat/chat.css">
</head>
<body>

<div id="chat-app" class="chat-app">

    <!-- Function Part -->
    <div id="function-section" class="function-section">
        <div id="tabs">
            <button type="button" class="tab active" onclick="openTab(event, 'recent-chat')">Recent Chat</button>
            <button type="button" class="tab" onclick="openTab(event, 'contact')">Contact</button>
        </div>
        
        <div id="chat-list-section">
            <!-- Chat list items will be dynamically generated here -->
        <div id="recent-chat" class="tabcontent" style="display:none">

        </div>

        <div id="contact" class="tabcontent" style="display:none">

        <button id="create-chat-button" type="button" class="tab">Create Chat</button>

        </div>

        </div>

        <div id="search-section">
            <input type="text" id="search-bar" placeholder="Enter to Search">
        </div>

        
    </div>

    <!-- Chat Area -->
    <div id="chat-section" class="chat-section">
        <div id="chat-header">
            <!-- Chat header content will be dynamically generated here -->
        </div>
        <div id="chat-messages">
            <!-- Chat messages will be dynamically generated here -->
        </div>
        <div id="chat-footer">
            <input type="text" id="chat-input" placeholder="Type here..." onkeydown="handleKeyDown(event)">
            <button id="send-button" onclick="sendMessage()">Send</button>
        </div>
    </div>

</div>

<template id="individual-chat-header">
    <load-svg class="topic-avatar" src="../assets/profile-icon.svg">
        <style shadowroot>
            svg {
                width: 50px;
                height: 50px;
            }
            .fill {
                fill: var(--label-color);
            }
        </style>
    </load-svg>
    <div class="name"></div>
    <div class="story"></div>
</template>

<template id="group-chat-header">
    <load-svg class="topic-avatar" src="../assets/group-icon.svg">
        <style shadowroot>
            svg {
                width: 50px;
                height: 50px;
            }
            .fill {
                fill: var(--label-color);
            }
        </style>
    </load-svg>
    <div class="name"></div>
    <div class="user-story"></div>
    <button id="leave-group-btn">Leave Group</button>
    <button id="add-member-btn">Add Member</button>
    <button id="group-info-btn">Group Info</button>
</template>

<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.7.5/socket.io.min.js"></script>
<script defer>
    // Initialize Socket.IO connection
    const socket = io('http://localhost:8080');

    // DOM elements
    const chatListSection = document.getElementById('chat-list-section');
    const chatHeader = document.getElementById('chat-header');
    const chatMessages = document.getElementById('chat-messages');
    const chatInput = document.getElementById('chat-input');
    const sendButton = document.getElementById('send-button');
    const searchBar = document.getElementById('search-bar');
    const button = document.getElementById('create-chat-button')

    // User data
    var currentUser = <?php echo $userId ? $userId : 'null'; ?>;
    var currentUserId = <?php echo $userId ? $userId : 'null'; ?>;
    let currentChatId = null;

    // Event listener for sending messages
    sendButton.addEventListener('click', sendMessage);
    function handleKeyDown(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

    // Event listener for search functionality
    searchBar.addEventListener('input', searchChatsAndContacts);

    // Function to load chat list
    function loadChatList() {

        // Clear existing chat list
        // chatListSection.innerHTML = '';
        recentChatDiv = document.getElementById('recent-chat')
        recentChatDiv.innerHTML = ''

        // Fetch chat list data from the server
        fetch(`http://localhost:8080/api/chat-list?userId=${currentUser}`)
            .then(response => response.json())
            .then(data => {
                // Generate chat list items dynamically
                data.forEach(chat => {
                    const chatItem = document.createElement('div');
                    chatItem.classList.add('chat-list-item');
                    chatItem.dataset.chatId = chat.id;
                    chatItem.dataset.chatType = chat.type;
                    chatItem.innerHTML = `
                        <load-svg class="topic-avatar" src="${chat.type === 'individual' ? '../assets/profile-icon.svg' : '../assets/group-icon.svg'}">
                            <style shadowroot>
                                svg {
                                    width: 50px;
                                    height: 50px;
                                }
                                .fill {
                                    <div id="recent-chat" class="tabcontent" style="display:none">

</div>

<div id="contact" class="tabcontent" style="display:none">

</div>            fill: var(--label-color);
                                }
                            </style>
                        </load-svg>
                        <div class="name">${chat.name}</div>
                    `;

                    chatItem.addEventListener('click', () => {
                        openChat(chat.id, chat.type, currentUser);
                    });

                    recentChatDiv.appendChild(chatItem);
                });
            })
            .catch(error => {
                console.error('Error fetching chat list:', error);
            });
    }

    function openTab(event, tabName) {
    // Get all elements with class="tabcontent" and hide them
    const tabContents = document.getElementsByClassName("tabcontent");
    for (let i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = "none";
    }

    // Get all elements with class="tab" and remove the class "active"
    const tabs = document.getElementsByClassName("tab");
    for (let i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove("active");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(tabName).style.display = "block";
    event.currentTarget.classList.add("active");

    if(tabName == 'contact'){
        document.getElementById("create-chat-button").style.display = "block" 
    }
    else{

        document.getElementById("create-chat-button").style.display = "none" 
    }
}





    // Function to load contacts
    function loadContacts() {
        // Clear existing chat list
        const recentContactDiv = document.getElementById('contact')
        recentContactDiv.innerHTML = '';
        // chatListSection.innerHTML = '';

        // Fetch contacts data from the server
        fetch('http://localhost:8080/api/contacts')
            .then(response => response.json())
            .then(data => {
                // Generate contact list items dynamically
                data.forEach(contact => {
                    const contactItem = document.createElement('div');
                    contactItem.classList.add('chat-list-item');
                    contactItem.dataset.contactId = contact.id;
                    if(contactItem.dataset.contactId == currentUser)
                    {

                    }
                    else{
                    contactItem.innerHTML = `
                        <load-svg class="topic-avatar" src="../assets/profile-icon.svg">
                            <style shadowroot>
                                svg {
                                    width: 50px;
                                    height: 50px;
                                }
                                .fill {
                                    fill: var(--label-color);
                                }
                            </style>
                        </load-svg>
                        <div class="name">${contact.first_name} ${contact.last_name}</div>
                    `;

                    // contactItem.addEventListener('click', () => {
                    //     openChat(contact.id, 'individual');
                    // });

                    recentContactDiv.appendChild(contactItem);
                    }
                });
                 // Create the 'create-chat-button' dynamically
            const createChatButton = document.createElement('button');
            createChatButton.id = 'create-chat-button';
            createChatButton.type = 'button';
            createChatButton.textContent = 'Create Chat';
            createChatButton.style.display = 'none'; // Initially hide the button

            // Append the button to the 'contact' tab
            recentContactDiv.appendChild(createChatButton);

            createChatButton.addEventListener('click', handleCreateChatButtonClick);

            initializeContactItemClickEvent()
            })
            .catch(error => {
                console.error('Error fetching contacts:', error);
            });
    }

    function openChat(chatId, chatType, userId) {
    currentChatId = chatId;

    // Clear existing chat header and messages
    chatHeader.innerHTML = '';
    chatMessages.innerHTML = '';

    // Emit the joinChat event to the server
    socket.emit('joinChat', chatId);

    // Fetch chat data from the server
    fetch(`http://localhost:8080/api/chats/${chatId}?userId=${userId}`)
        .then(response => response.json())
        .then(data => {
            if (chatType === 'individual') {
                // Fetch the other user's name and user story for individual chats
                const otherUserId = data.user1_id === userId ? data.user2_id : data.user1_id;
                fetch(`http://localhost:8080/api/user?userId=${otherUserId}`)
                    .then(response => response.json())
                    .then(userData => {
                        data.name = userData.full_name;
                        data.story = userData.story || ''; // Get the user story from the response data
                        generateChatHeader(data, chatType);
                        loadChatMessages();
                    })
                    .catch(error => {
                        console.error('Error fetching user data:', error);
                        data.name = 'Unknown User';
                        data.story = '';
                        generateChatHeader(data, chatType);
                        loadChatMessages();
                    });
            } else {
                generateChatHeader(data, chatType);
                loadChatMessages();
            }
        })
        .catch(error => {
            console.error('Error fetching chat data:', error);
        });

    function loadChatMessages() {
        // Fetch chat messages from the server
        fetch(`http://localhost:8080/api/chats/${chatId}/messages`)
            .then(response => response.json())
            .then(messages => {
                // Sort messages by timestamp
                messages.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));

                // Generate chat messages dynamically
                messages.forEach(message => {
                    const messageElement = createMessageElement(message);
                    chatMessages.appendChild(messageElement);
                });
                scrollToBottom();
            })
            .catch(error => {
                console.error('Error fetching chat messages:', error);
            });
    }
}

function generateChatHeader(chatData, chatType) {
    // Load chat header
    const headerTemplate = document.getElementById(chatType === 'individual' ? 'individual-chat-header' : 'group-chat-header').content.cloneNode(true);
    
    if (chatType === 'individual') {
        headerTemplate.querySelector('.name').textContent = chatData.name;
        headerTemplate.querySelector('.story').textContent = chatData.story;
    } else {
        headerTemplate.querySelector('.name').textContent = chatData.name;
        
        // Event listeners for group chat actions
        headerTemplate.querySelector('#leave-group-btn').addEventListener('click', leaveGroup);
        headerTemplate.querySelector('#add-member-btn').addEventListener('click', addMember);
        headerTemplate.querySelector('#group-info-btn').addEventListener('click', showGroupInfo);
    }
    
    chatHeader.appendChild(headerTemplate);
}
    // Function to create a message element
    function createMessageElement(message) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message');
        messageElement.classList.add(message.sender_id === currentUser ? 'out-message' : 'in-message');


        const senderName = message.sender_id === currentUser ? 'You' : message.sender_name;

        messageElement.innerHTML = `
            ${message.sender_id === currentUser ? `
                <div class="message-content">
                    <div class="message-sender">${senderName}</div>
                    <div class="message-text">${message.content}</div>
                    <div class="message-time">${formatTimestamp(message.created_at)}</div>
                </div>
                <load-svg class="topic-avatar" src="../assets/profile-icon.svg">
                    <style shadowroot>
                        svg {
                            width: 50px;
                            height: 50px;
                        }
                        .fill {
                            fill: var(--label-color);
                        }
                    </style>
                </load-svg>
            ` : `
                <load-svg class="topic-avatar" src="../assets/profile-icon.svg">
                    <style shadowroot>
                        svg {
                            width: 50px;
                            height: 50px;
                        }
                        .fill {
                            fill: var(--label-color);
                        }
                    </style>
                </load-svg>
                <div class="message-content">
                    <div class="message-sender">${senderName}</div>
                    <div class="message-text">${message.content}</div>
                    <div class="message-time">${formatTimestamp(message.created_at)}</div>
                </div>
            `}
        `;

        return messageElement;
    }
    

    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Function to open a chat
    // function openChat(chatId, chatType) {
    //     currentChatId = chatId;
    //     // Clear existing chat header and messages
    //     chatHeader.innerHTML = '';
    //     chatMessages.innerHTML = '';

    //     socket.emit('joinChat', chatId);

    //     // Fetch chat data from the server
    //     fetch(`http://localhost:8080/api/chats/${chatId}`)
    //         .then(response => response.json())
    //         .then(data => {
    //             // Load chat header
    //             const headerTemplate = document.getElementById(chatType === 'individual' ? 'individual-chat-header' : 'group-chat-header').content.cloneNode(true);
    //             if(chatType == 'individual'){
    //             headerTemplate.querySelector('.name').innerHTML = data[0].name;
    //             headerTemplate.querySelector('.user-story').textContent = data.userStory;
    //             }
    //             // Event listeners for group chat actions
    //             if (chatType === 'group') {
    //                 headerTemplate.querySelector('#leave-group-btn').addEventListener('click', leaveGroup);
    //                 headerTemplate.querySelector('#add-member-btn').addEventListener('click', addMember);
    //                 headerTemplate.querySelector('#group-info-btn').addEventListener('click', showGroupInfo);
    //             }

    //             chatHeader.appendChild(headerTemplate);

                

    //             // Scroll to the bottom of the chat messages
    //             chatMessages.scrollTop = chatMessages.scrollHeight;
    //         })
    //         .catch(error => {
    //             console.error('Error fetching chat data:', error);
    //         });
            
    //     fetch(`http://localhost:8080/api/chats/${chatId}/messages`)
    //     .then(response => response.json())
    //     .then(data => {
    //             data.forEach(message =>{
    //             const messageElement = document.createElement('div');
    //                 messageElement.classList.add('message');
    //                 messageElement.classList.add(message.sender_id === currentUser ? 'out-message' : 'in-message');

    //                 const senderName = message.sender_id === currentUser ? 'You' : message.senderName;

    //                 messageElement.innerHTML = `
    //                     ${message.senderId === currentUser ? `
    //                         <div class="message-content">
    //                             <div class="message-sender">${senderName}</div>
    //                             <div class="message-text">${message.content}</div>
    //                             <div class="message-time">${formatTimestamp(message.created_at)}</div>
    //                         </div>
    //                         <load-svg class="topic-avatar" src="../assets/profile-icon.svg">
    //                             <style shadowroot>
    //                                 svg {
    //                                     width: 50px;
    //                                     height: 50px;
    //                                 }
    //                                 .fill {
    //                                     fill: var(--label-color);
    //                                 }
    //                             </style>
    //                         </load-svg>
    //                     ` : `
    //                         <load-svg class="topic-avatar" src="../assets/profile-icon.svg">
    //                             <style shadowroot>
    //                                 svg {
    //                                     width: 50px;
    //                                     height: 50px;
    //                                 }
    //                                 .fill {
    //                                     fill: var(--label-color);
    //                                 }
    //                             </style>
    //                         </load-svg>
    //                         <div class="message-content">
    //                             <div class="message-sender">${senderName}</div>
    //                             <div class="message-text">${message.content}</div>
    //                             <div class="message-time">${formatTimestamp(message.created_at)}</div>
    //                         </div>
    //                     `}
    //                 `;

    //                 chatMessages.appendChild(messageElement);
    //         })
            
    //     })
    // }

    // Function to send a message
    function sendMessage() {
        const messageText = chatInput.value.trim();

        if (messageText !== '') {
            const messageData = {
                chatId: currentChatId,
                senderId: currentUser,
                content: messageText
            };

            // Emit the message to the server
            socket.emit('message', messageData);

            // Clear the chat input
            chatInput.value = '';
        }
    }

    // Function to format timestamp
    function formatTimestamp(timestamp) {
        const date = new Date(timestamp);
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        return `${hours}:${minutes}`;
    }

    // Function to search chats and contacts
    function searchChatsAndContacts() {
        const searchTerm = searchBar.value.toLowerCase();
        if (searchTerm === '') {
        // Clear the chat list section if the search term is empty
        chatListSection.innerHTML = '';
	    // loadChatList()
        return;
        }

        // Fetch search results from the server
        fetch(`http://localhost:8080/api/search?term=${encodeURIComponent(searchTerm)}&userId=${currentUserId}`)
            .then(response => response.json())
            .then(data => {
                // Clear existing chat list
                chatListSection.innerHTML = '';
                if(data.chats && data.chats.forEach){
                    data.chats.forEach(chat => {
                    const chatItem = document.createElement('div');
                    chatItem.classList.add('chat-list-item', 'chat-item');
                    chatItem.dataset.chatId = chat.id;
                    chatItem.dataset.chatType = chat.type;
                    chatItem.innerHTML = `
                        <load-svg class="topic-avatar" src="${chat.type === 'individual' ? '../assets/chat-icon.svg' : '../assets/group-icon.svg'}">
                            <style shadowroot>
                                svg {
                                    width: 50px;
                                    height: 50px;
                                }
                                .fill {
                                    fill: var(--label-color);
                                }
                            </style>
                        </load-svg>
                        <div class="name">${chat.name}</div>
                        <span class="chat-badge">Chat</span>
                    `;

                    chatItem.addEventListener('click', () => {
                        openChat(chat.id, chat.type);
                    });

                    chatListSection.appendChild(chatItem);
                });

            }
    if (data.contacts && data.contacts.forEach) {
        data.contacts.forEach(contact => {
            const contactItem = document.createElement('div');
            contactItem.classList.add('chat-list-item', 'contact-item');
            contactItem.dataset.contactId = contact.id;
            contactItem.innerHTML = `
                <load-svg class="topic-avatar" src="../assets/profile-icon.svg">
                    <style shadowroot>
                        svg {
                            width: 50px;
                            height: 50px;
                        }
                        .fill {
                            fill: var(--label-color);
                        }
                    </style>
                </load-svg>
                <div class="name">${contact.name}</div>
                <span class="contact-badge">Contact</span>
            `;

            contactItem.addEventListener('click', () => {
                openContactModal(contact.id);
            });

            chatListSection.appendChild(contactItem);
        });
             }
                
            })
            .catch(error => {
                console.error('Error fetching search results:', error);
            });
    }

    // Function to leave a group
    function leaveGroup() {
        // Emit the leave group event to the server
        socket.emit('leaveGroup', { 
        chatId: currentChatId,
        userId: currentUserId
    });


        // Navigate back to the chat list
        loadChatList();
        setTimeout(() => {
            location.reload();
        }, 25);
    }

    // Function to add a member to a group
    function addMember() {
        const memberId = prompt('Enter the user ID of the member to add:');

        if (memberId) {
            // Emit the add member event to the server
            fetch(`http://localhost:8080/api/chats/${currentChatId}/addMember/${memberId}`)
            .then(response => {
                if(response.ok)
                alert("Member Added!")
                else{
                    alert("Error Adding Member")
                }
            })
            // socket.emit('addMember', { chatId: currentChatId, memberId });
        }
    }

    // Function to show group info
    function showGroupInfo() {
        // Fetch group info from the server
        fetch(`http://localhost:8080/api/chats/${currentChatId}/groupInfo`)
            .then(response => response.json())
            .then(data => {
                // Display group info in a modal or dialog
                alert(`Members:\n\n${data.join('\n')}`);
            })
            .catch(error => {
                console.error('Error fetching group info:', error);
            });
    }

    // Event listeners for socket events
    socket.on('message', (message) => {
    if (message.chat_room_id === currentChatId) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message');
        messageElement.classList.add(message.sender_id === currentUser ? 'out-message' : 'in-message');

        const senderName = message.sender_id === currentUser ? 'You' : message.sender_name;

        messageElement.innerHTML = `
            ${message.sender_id === currentUser ? `
                <div class="message-content">
                    <div class="message-sender">${senderName}</div>
                    <div class="message-text">${message.content}</div>
                    <div class="message-time">${formatTimestamp(message.created_at)}</div>
                </div>
                <load-svg class="topic-avatar" src="../assets/profile-icon.svg">
                    <style shadowroot>
                        svg {
                            width: 50px;
                            height: 50px;
                        }
                        .fill {
                            fill: var(--label-color);
                        }
                    </style>
                </load-svg>
            ` : `
                <load-svg class="topic-avatar" src="../assets/profile-icon.svg">
                    <style shadowroot>
                        svg {
                            width: 50px;
                            height: 50px;
                        }
                        .fill {
                            fill: var(--label-color);
                        }
                    </style>
                </load-svg>
                <div class="message-content">
                    <div class="message-sender">${senderName}</div>
                    <div class="message-text">${message.content}</div>
                    <div class="message-time">${formatTimestamp(message.created_at)}</div>
                </div>
            `}
        `;

        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }
});

    socket.on('memberAdded', (data) => {
        if (data.chatId === currentChatId) {
            // Reload the chat to update the member list
            openChat(currentChatId, 'group');
        }
    });

    socket.on('memberLeft', (data) => {
        if (data.chatId === currentChatId) {
            // Reload the chat to update the member list
            openChat(currentChatId, 'group');
        }
    });

    


    // New functions added below 
    // Array to store selected contacts
    let selectedContacts = [];

    // Function to toggle contact selection
    function toggleContactSelection(contactId) {
        const index = selectedContacts.indexOf(contactId);
        if (index === -1) {
            // Contact not selected, add it to the array
            selectedContacts.push(contactId);
        } else {
            // Contact already selected, remove it from the array
            selectedContacts.splice(index, 1);
        }
    }

    // Function to handle contact item click
    function handleContactItemClick(contactId) {
        // Toggle contact selection
        toggleContactSelection(contactId);

        // Add visual indication of selection (e.g., change background color)
        const contactItem = document.querySelector(`.chat-list-item[data-contact-id="${contactId}"]`);
        if (selectedContacts.includes(contactId)) {
            // Contact selected
            contactItem.classList.add('selected');
            contactItem.style.backgroundColor = "green"
        } else {
            // Contact deselected
            contactItem.classList.remove('selected');
            contactItem.style.backgroundColor = "white"
        }
    }

    // Event listener for contact item click
    function initializeContactItemClickEvent() {
        const contactItems = document.querySelectorAll('.chat-list-item[data-contact-id]');
        contactItems.forEach(contactItem => {
            const contactId = parseInt(contactItem.dataset.contactId);
            contactItem.addEventListener('click', () => {
                handleContactItemClick(contactId);
            });
        });
    }

    // Function to handle "Create Chat" button click
    function handleCreateChatButtonClick() {
        // Check if at least one contact is selected
        if (selectedContacts.length > 0) {
            selectedContacts.push(currentUser)
            // Create a chat with selected contacts
            createChat(selectedContacts);
            
            // Clear selected contacts
            selectedContacts = [];

            // Clear visual indication of selection (e.g., remove background color)
            const contactItems = document.querySelectorAll('.chat-list-item.selected');
            contactItems.forEach(contactItem => {
                contactItem.classList.remove('selected');
                contactItem.style.backgroundColor = "white"
            });
        } else {
            // Inform the user to select at least one contact
            alert('Please select at least one contact to create a chat.');
        }
    }

    function createChat(selectedContacts){
        if(selectedContacts.length == 2){
        const user_1 = selectedContacts[0]
        const user_2 = selectedContacts[1]
        const contactData = {
            selectedContacts :selectedContacts,
            chatType: "individual",
            chatName: "",
            user1:user_1,
            user2:user_2
        }
        fetch('http://localhost:8080/api/createChat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(contactData)
        })
        .then(response => {
            if (response.ok) {
                return response.json();
            }
            throw new Error("Some mistake with the response received.");
        })
        .then(data => {
            console.log(data);
            if (data.reload) {
                // Reload the page
                window.location.reload();
            }
        })
        .catch(error => {
            console.error(error);
        });
        }
        else{
            const groupname = prompt('Enter the group name :');
            
           const groupData = {
            selectedContacts:selectedContacts, 
            chatName: groupname,
            chatType: "group"
           } 
            fetch('http://localhost:8080/api/createGroup', {
            method: 'POST',
            headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(groupData)
            })
            .then(response => {
            if (response.ok) {
            return response.json(); 
        }
        throw new Error("Some mistake with the response received.");
            })
            .then(data => {
            console.log(data);
            if (data.reload) {
        // Reload the page
            window.location.reload();
            }
            })
        .catch(error => {
            console.error(error);
            });
        }
    }

    // Event listener for "Create Chat" button click
    // const createChatButton = document.getElementById('create-chat-button');
    // createChatButton.addEventListener('click', () => {
    //     console.log("Clicked!");
    // });




    // Initialize the chat application
    function initializeChat() {
        // Fetch the current user data from the server
        loadContacts();

        fetch(`http://localhost:8080/api/user?userId=${currentUserId}`)
            .then(response => response.json())
            .then(data => {
                // currentUser = data;
                loadChatList();
                const recentChatTabButton = document.querySelector('#tabs .tab:nth-child(1)');
                recentChatTabButton.click(); // Simulate a click event
            })
            .catch(error => {
                console.error('Error fetching user data:', error);
            });
    }

    // Call the initialization function when the page loads
    window.addEventListener('DOMContentLoaded', initializeChat);
</script>

</body>
</html>
