# 22COB290 Team Project

This is Team 02's team project – making a productivity and knowledge management system for the company Make-It-All.
